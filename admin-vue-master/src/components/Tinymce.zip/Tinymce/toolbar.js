// Here is a list of the toolbar
// Detail list see https://www.tinymce.com/docs/advanced/editor-control-identifiers/#toolbarcontrols

const toolbar = [
  'bold italic underline strikethrough alignleft aligncenter alignright outdent indent blockquote undo redo removeformat code codesample',
  'hr bullist numlist link image charmap preview pagebreak insertdatetime media emoticons forecolor backcolor fullscreen',
  'fontsizeselect  fontselect',
];
// 'searchreplace bold italic underline strikethrough alignleft aligncenter alignright outdent indent  blockquote undo redo removeformat subscript superscript code codesample fontsizeselect  fontselect',
//   'hr bullist numlist link image charmap preview anchor pagebreak insertdatetime media table emoticons forecolor backcolor fullscreen',
export default toolbar;
